<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$configFile = __DIR__ . '/config.php';
if (!is_file($configFile)) {
    respond(503, ['ok' => false, 'message' => 'CMS is not configured. Copy api/config.example.php to api/config.php.']);
}
require $configFile;

const COLLECTIONS = ['news', 'home_testimonials', 'program_testimonials', 'team', 'podcasts', 'reports', 'stories', 'gallery', 'filters'];

function respond(int $status, array $payload)
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function request_body(): array
{
    $decoded = json_decode((string) file_get_contents('php://input'), true);
    return is_array($decoded) ? $decoded : [];
}

function bearer_token(): string
{
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
    if (preg_match('/^Bearer\s+(.+)$/i', $header, $matches)) {
        return trim($matches[1]);
    }
    return '';
}

function token_for(string $username, int $expires): string
{
    $payload = base64_encode(json_encode(['user' => $username, 'exp' => $expires]));
    $signature = hash_hmac('sha256', $payload, CMS_SECRET);
    return $payload . '.' . $signature;
}

function require_admin(): void
{
    $parts = explode('.', bearer_token(), 2);
    if (count($parts) !== 2 || !hash_equals(hash_hmac('sha256', $parts[0], CMS_SECRET), $parts[1])) {
        respond(401, ['ok' => false, 'message' => 'Unauthorized. Please sign in again.']);
    }
    $payload = json_decode((string) base64_decode($parts[0], true), true);
    if (!is_array($payload) || ($payload['exp'] ?? 0) < time() || ($payload['user'] ?? '') !== ADMIN_USERNAME) {
        respond(401, ['ok' => false, 'message' => 'Unauthorized. Please sign in again.']);
    }
}

function collection_name($value): string
{
    $collection = is_string($value) ? $value : '';
    if (!in_array($collection, COLLECTIONS, true)) {
        respond(400, ['ok' => false, 'message' => 'Invalid content collection.']);
    }
    return $collection;
}

function data_file(string $collection): string
{
    if (!is_dir(CMS_DATA_DIR) && !mkdir(CMS_DATA_DIR, 0755, true) && !is_dir(CMS_DATA_DIR)) {
        respond(500, ['ok' => false, 'message' => 'Unable to create the CMS storage directory.']);
    }
    return CMS_DATA_DIR . '/' . $collection . '.json';
}

function read_items(string $collection): array
{
    $file = data_file($collection);
    if (!is_file($file)) return [];
    $handle = fopen($file, 'rb');
    if ($handle === false) return [];
    flock($handle, LOCK_SH);
    $decoded = json_decode((string) stream_get_contents($handle), true);
    flock($handle, LOCK_UN);
    fclose($handle);
    return is_array($decoded) ? array_values($decoded) : [];
}

function write_items(string $collection, array $items): void
{
    $file = data_file($collection);
    $handle = fopen($file, 'c+');
    if ($handle === false || !flock($handle, LOCK_EX)) {
        respond(500, ['ok' => false, 'message' => 'Unable to lock the CMS data file.']);
    }
    ftruncate($handle, 0);
    rewind($handle);
    fwrite($handle, (string) json_encode(array_values($items), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    fflush($handle);
    flock($handle, LOCK_UN);
    fclose($handle);
}

function clean_string($value, int $max = 20000): string
{
    $cleaned = trim(is_string($value) ? $value : '');
    return function_exists('mb_substr')
        ? mb_substr($cleaned, 0, $max)
        : substr($cleaned, 0, $max);
}

function normalize_item(array $input, string $collection, ?array $existing = null): array
{
    $now = gmdate('c');
    $shorts = [];
    foreach ((is_array($input['shorts'] ?? null) ? $input['shorts'] : []) as $short) {
        if (!is_array($short)) continue;
        $shorts[] = [
            'id' => clean_string($short['id'] ?? '') ?: bin2hex(random_bytes(6)),
            'title_en' => clean_string($short['title_en'] ?? '', 500),
            'title_ar' => clean_string($short['title_ar'] ?? '', 500),
            'youtube_url' => clean_string($short['youtube_url'] ?? '', 2000),
        ];
    }
    return [
        'id' => clean_string($input['id'] ?? '') ?: bin2hex(random_bytes(8)),
        'collection' => $collection,
        'title_en' => clean_string($input['title_en'] ?? '', 500),
        'title_ar' => clean_string($input['title_ar'] ?? '', 500),
        'body_en' => clean_string($input['body_en'] ?? ''),
        'body_ar' => clean_string($input['body_ar'] ?? ''),
        'subtitle_en' => clean_string($input['subtitle_en'] ?? '', 1000),
        'subtitle_ar' => clean_string($input['subtitle_ar'] ?? '', 1000),
        'image_path' => clean_string($input['image_path'] ?? '', 2000),
        'media_path' => clean_string($input['media_path'] ?? '', 2000),
        'external_url' => clean_string($input['external_url'] ?? '', 2000),
        'program' => clean_string($input['program'] ?? '', 200),
        'published_at' => clean_string($input['published_at'] ?? date('Y-m-d'), 40),
        'published' => (bool) ($input['published'] ?? false),
        'featured' => (bool) ($input['featured'] ?? false),
        'sort_order' => (int) ($input['sort_order'] ?? 0),
        'filter_id' => clean_string($input['filter_id'] ?? '', 100),
        'shorts' => $shorts,
        'created_at' => $existing['created_at'] ?? $now,
        'updated_at' => $now,
    ];
}

function image_to_webp(string $source, string $destination, string $mime): bool
{
    if (!function_exists('imagewebp')) return false;
    $image = false;
    if ($mime === 'image/jpeg') {
        $image = @imagecreatefromjpeg($source);
    } elseif ($mime === 'image/png') {
        $image = @imagecreatefrompng($source);
    } elseif ($mime === 'image/webp') {
        $image = @imagecreatefromwebp($source);
    }
    if (!$image) return false;

    $width = imagesx($image);
    $height = imagesy($image);
    $max = 1920;
    $scale = min(1, $max / max($width, $height));
    $newWidth = max(1, (int) round($width * $scale));
    $newHeight = max(1, (int) round($height * $scale));
    $canvas = imagecreatetruecolor($newWidth, $newHeight);
    imagealphablending($canvas, false);
    imagesavealpha($canvas, true);
    imagecopyresampled($canvas, $image, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);
    $saved = imagewebp($canvas, $destination, 82);
    imagedestroy($canvas);
    imagedestroy($image);
    return $saved;
}

function upload_file()
{
    $kind = $_POST['kind'] ?? '';
    $allowed = [
        'image' => ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'],
        'document' => ['application/pdf' => 'pdf'],
        'video' => ['video/mp4' => 'mp4', 'video/webm' => 'webm'],
    ];
    $limits = ['image' => 12 * 1024 * 1024, 'document' => 40 * 1024 * 1024, 'video' => 250 * 1024 * 1024];
    if (!isset($allowed[$kind], $_FILES['file']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
        respond(400, ['ok' => false, 'message' => 'A valid upload is required.']);
    }
    if ($_FILES['file']['error'] !== UPLOAD_ERR_OK || $_FILES['file']['size'] > $limits[$kind]) {
        respond(413, ['ok' => false, 'message' => 'The uploaded file is too large or incomplete.']);
    }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($_FILES['file']['tmp_name']);
    if (!isset($allowed[$kind][$mime])) {
        respond(415, ['ok' => false, 'message' => 'This file format is not allowed.']);
    }

    $folder = CMS_UPLOAD_DIR . '/' . $kind;
    if (!is_dir($folder) && !mkdir($folder, 0755, true) && !is_dir($folder)) {
        respond(500, ['ok' => false, 'message' => 'Unable to create the upload directory.']);
    }
    $base = date('Ymd-His') . '-' . bin2hex(random_bytes(5));
    $extension = $allowed[$kind][$mime];
    $destination = $folder . '/' . $base . '.' . $extension;

    if ($kind === 'image') {
        if (!image_to_webp($_FILES['file']['tmp_name'], $folder . '/' . $base . '.webp', $mime)) {
            respond(500, ['ok' => false, 'message' => 'WebP conversion is unavailable. Enable PHP GD with WebP support in cPanel.']);
        }
        $extension = 'webp';
    } elseif (!move_uploaded_file($_FILES['file']['tmp_name'], $destination)) {
        respond(500, ['ok' => false, 'message' => 'Unable to store the uploaded file.']);
    }
    respond(200, ['ok' => true, 'path' => CMS_UPLOAD_URL . '/' . $kind . '/' . $base . '.' . $extension]);
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $collection = collection_name($_GET['collection'] ?? '');
    $admin = ($_GET['admin'] ?? '') === '1';
    if ($admin) require_admin();
    $items = read_items($collection);
    if (!$admin) {
        $items = array_values(array_filter($items, function (array $item): bool {
            return (bool) ($item['published'] ?? false);
        }));
    }
    usort($items, function (array $a, array $b): int {
        $order = ($a['sort_order'] ?? 0) <=> ($b['sort_order'] ?? 0);
        return $order !== 0 ? $order : strcmp((string) ($b['published_at'] ?? ''), (string) ($a['published_at'] ?? ''));
    });
    respond(200, ['ok' => true, 'items' => $items]);
}

if ($method !== 'POST') respond(405, ['ok' => false, 'message' => 'Method not allowed.']);

$contentType = $_SERVER['CONTENT_TYPE'] ?? '';
$body = strpos($contentType, 'multipart/form-data') === 0 ? $_POST : request_body();
$action = $body['action'] ?? '';

if ($action === 'login') {
    $username = clean_string($body['username'] ?? '', 200);
    $password = is_string($body['password'] ?? null) ? $body['password'] : '';
    $passwordMatches = defined('ADMIN_PASSWORD_HASH')
        && ADMIN_PASSWORD_HASH !== ''
        && password_verify($password, ADMIN_PASSWORD_HASH);
    if (!$passwordMatches && defined('ADMIN_PASSWORD_PBKDF2') && defined('ADMIN_PASSWORD_SALT')) {
        $iterations = defined('ADMIN_PASSWORD_ITERATIONS') ? ADMIN_PASSWORD_ITERATIONS : 210000;
        $candidate = hash_pbkdf2('sha256', $password, ADMIN_PASSWORD_SALT, $iterations, 64);
        $passwordMatches = hash_equals(ADMIN_PASSWORD_PBKDF2, $candidate);
    }
    if (!hash_equals(ADMIN_USERNAME, $username) || !$passwordMatches) {
        usleep(500000);
        respond(401, ['ok' => false, 'message' => 'Incorrect username or password.']);
    }
    respond(200, ['ok' => true, 'token' => token_for($username, time() + 8 * 60 * 60)]);
}

require_admin();
if ($action === 'upload') upload_file();

$collection = collection_name($body['collection'] ?? ($body['item']['collection'] ?? ''));
$items = read_items($collection);

if ($action === 'reorder') {
    $ids = is_array($body['ids'] ?? null) ? array_values($body['ids']) : [];
    $positions = [];
    foreach ($ids as $position => $id) {
        if (is_string($id)) $positions[$id] = $position;
    }
    foreach ($items as &$item) {
        $id = (string) ($item['id'] ?? '');
        if (array_key_exists($id, $positions)) {
            $item['sort_order'] = $positions[$id];
            $item['updated_at'] = gmdate('c');
        }
    }
    unset($item);
    write_items($collection, $items);
    respond(200, ['ok' => true]);
}

if ($action === 'save') {
    $input = is_array($body['item'] ?? null) ? $body['item'] : [];
    $existing = null;
    foreach ($items as $candidate) {
        if (($candidate['id'] ?? '') === ($input['id'] ?? '')) $existing = $candidate;
    }
    $item = normalize_item($input, $collection, $existing);
    $items = array_values(array_filter($items, function (array $candidate) use ($item): bool {
        return ($candidate['id'] ?? '') !== $item['id'];
    }));
    $items[] = $item;
    write_items($collection, $items);
    respond(200, ['ok' => true, 'item' => $item]);
}

if ($action === 'delete') {
    $id = clean_string($body['id'] ?? '', 100);
    $items = array_values(array_filter($items, function (array $item) use ($id): bool {
        return ($item['id'] ?? '') !== $id;
    }));
    write_items($collection, $items);
    respond(200, ['ok' => true]);
}

respond(400, ['ok' => false, 'message' => 'Unknown CMS action.']);
