<?php
declare(strict_types=1);

$configFile = __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
if (!is_file($configFile)) {
    http_response_code(503);
    echo json_encode(['ok' => false, 'message' => 'CMS is not configured.']);
    exit;
}
require $configFile;

$language = ($_GET['lang'] ?? 'en') === 'ar' ? 'ar' : 'en';
$limit = max(1, min(20, (int) ($_GET['limit'] ?? 4)));
$file = CMS_DATA_DIR . '/news.json';
$items = is_file($file) ? json_decode((string) file_get_contents($file), true) : [];
$items = is_array($items) ? $items : [];
$items = array_values(array_filter($items, function (array $item): bool {
    return (bool) ($item['published'] ?? false);
}));
usort($items, function (array $a, array $b): int {
    return strcmp((string) ($b['published_at'] ?? ''), (string) ($a['published_at'] ?? ''));
});
$items = array_slice($items, 0, $limit);
$mapped = array_map(function (array $item) use ($language): array {
    return [
        'id' => (string) ($item['id'] ?? ''),
        'title' => (string) ($item['title_' . $language] ?? ''),
        'body' => (string) ($item['body_' . $language] ?? ''),
        'image_path' => (string) ($item['image_path'] ?? ''),
        'published_at' => (string) ($item['published_at'] ?? ''),
    ];
}, $items);

echo json_encode(['ok' => true, 'items' => $mapped], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
